# AchaPromo 🏷️ — Guia de promoções para Android

App em **Kotlin + Jetpack Compose (Material 3)** que reúne ofertas das principais lojas online e
responde às dúvidas mais comuns do consumidor.

## O que o app tem

- **Ofertas**: busca, filtros por categoria, ordenação (maior desconto / menor preço), filtro de frete grátis,
  cupom que copia com um toque e botão "Ver na loja" que abre o site/app da loja.
- **Lojas**: Amazon, Mercado Livre, Magalu, Shopee, KaBuM!, Casas Bahia, AliExpress e Shein, com dicas de compra.
- **Favoritos**: salvos no aparelho (SharedPreferences).
- **Guia do consumidor**: calculadora de desconto real, calculadora Pix x parcelado, 11 dúvidas frequentes
  (arrependimento, garantia, golpes, cupons, compras internacionais…), checklist antes de comprar e
  calendário de datas promocionais, além de contagem regressiva para a Black Friday.
- Tema claro e escuro automático, ícone adaptativo, Android 8.0+ (API 26).

## Como abrir e rodar

1. Instale o [Android Studio](https://developer.android.com/studio) (versão recente).
2. `File > Open` e selecione a pasta `AchaPromo`.
3. Aguarde o *Gradle Sync* (ele baixa as dependências e cria o Gradle Wrapper).
4. Clique em **Run ▶** com um celular conectado ou um emulador.

Para gerar o APK: `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
Para publicar na Play Store: `Build > Generate Signed Bundle / APK` (formato AAB).

## ⚠️ Importante: os dados são de demonstração

Os produtos e preços em `data/SampleData.kt` são **ilustrativos** (e os cupons `DEMO…` não existem).
Antes de publicar, troque por dados reais, por exemplo:

- um JSON/API próprio ou Firebase Firestore que você atualiza todo dia;
- programas de afiliados e APIs oficiais das lojas (Mercado Livre, Amazon Associates, Awin, Lomadee etc.),
  que também permitem ganhar comissão pelas vendas.

Basta substituir `SampleData.offers` por uma lista carregada da sua fonte, mantendo o modelo `Offer`.

## Antes de publicar

- Crie uma **política de privacidade** (exigida pela Play Store e pela LGPD).
- Marcas e nomes das lojas pertencem aos seus donos; o app não deve se apresentar como oficial delas.
- Se usar links de afiliado, informe isso ao usuário.

## Estrutura

```
app/src/main/java/br/com/achapromo/
├── MainActivity.kt          # navegação por abas
├── data/                    # modelos e dados de exemplo
├── ui/                      # ViewModel, componentes e tema
│   └── screens/             # Ofertas, Lojas, Favoritos, Guia
└── util/Utils.kt            # formatação de moeda, abrir links, Black Friday
```
