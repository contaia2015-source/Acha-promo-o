package br.com.achapromo.ui

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import br.com.achapromo.data.Category
import br.com.achapromo.data.Offer
import br.com.achapromo.data.SampleData

enum class Sort(val label: String) {
    DISCOUNT("Maior desconto"),
    PRICE("Menor preço")
}

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("achapromo", Context.MODE_PRIVATE)

    var query by mutableStateOf("")
    var category by mutableStateOf(Category.ALL)
    var sort by mutableStateOf(Sort.DISCOUNT)
    var onlyFreeShipping by mutableStateOf(false)

    var favorites by mutableStateOf(loadFavorites())
        private set

    val offers: List<Offer>
        get() {
            val q = query.trim().lowercase()
            return SampleData.offers.asSequence()
                .filter { category == Category.ALL || it.category == category }
                .filter { !onlyFreeShipping || it.freeShipping }
                .filter {
                    q.isEmpty() ||
                        it.title.lowercase().contains(q) ||
                        it.store.name.lowercase().contains(q)
                }
                .sortedWith(
                    when (sort) {
                        Sort.DISCOUNT -> compareByDescending<Offer> { it.discountPercent }
                        Sort.PRICE -> compareBy<Offer> { it.price }
                    }
                )
                .toList()
        }

    val favoriteOffers: List<Offer>
        get() = SampleData.offers.filter { it.id in favorites }

    fun toggleFavorite(id: Int) {
        favorites = if (id in favorites) favorites - id else favorites + id
        prefs.edit()
            .putStringSet("fav", favorites.map { it.toString() }.toSet())
            .apply()
    }

    private fun loadFavorites(): Set<Int> =
        prefs.getStringSet("fav", emptySet())
            .orEmpty()
            .mapNotNull { it.toIntOrNull() }
            .toSet()
}
