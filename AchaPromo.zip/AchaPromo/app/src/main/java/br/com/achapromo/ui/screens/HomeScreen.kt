package br.com.achapromo.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import br.com.achapromo.data.Category
import br.com.achapromo.ui.Disclaimer
import br.com.achapromo.ui.EmptyState
import br.com.achapromo.ui.MainViewModel
import br.com.achapromo.ui.OfferCard
import br.com.achapromo.ui.Sort
import br.com.achapromo.util.daysToBlackFriday
import br.com.achapromo.util.openUrl

@Composable
fun HomeScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val offers = vm.offers

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { HeroBanner() }

        item {
            OutlinedTextField(
                value = vm.query,
                onValueChange = { vm.query = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(28.dp),
                placeholder = { Text("Buscar produto ou loja…") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                trailingIcon = {
                    if (vm.query.isNotEmpty()) {
                        IconButton(onClick = { vm.query = "" }) {
                            Icon(Icons.Filled.Clear, contentDescription = "Limpar busca")
                        }
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface
                )
            )
        }

        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(Category.entries) { c ->
                    FilterChip(
                        selected = vm.category == c,
                        onClick = { vm.category = c },
                        label = { Text("${c.emoji} ${c.label}") }
                    )
                }
            }
        }

        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(Sort.entries) { s ->
                    FilterChip(
                        selected = vm.sort == s,
                        onClick = { vm.sort = s },
                        label = { Text(s.label) }
                    )
                }
                item {
                    FilterChip(
                        selected = vm.onlyFreeShipping,
                        onClick = { vm.onlyFreeShipping = !vm.onlyFreeShipping },
                        label = { Text("🚚 Frete grátis") }
                    )
                }
            }
        }

        item {
            Text(
                text = if (offers.size == 1) "1 oferta encontrada" else "${offers.size} ofertas encontradas",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        if (offers.isEmpty()) {
            item {
                EmptyState(
                    emoji = "🔍",
                    title = "Nada por aqui",
                    message = "Tente outra palavra ou limpe os filtros para ver mais ofertas."
                )
            }
        }

        items(offers, key = { it.id }) { offer ->
            OfferCard(
                offer = offer,
                isFavorite = offer.id in vm.favorites,
                onToggleFavorite = { vm.toggleFavorite(offer.id) },
                onOpen = { context.openUrl(offer.store.searchUrl(offer.searchTerm)) }
            )
        }

        item {
            Disclaimer(
                "Ofertas de demonstração. Preços e disponibilidade podem mudar: " +
                    "sempre confirme o valor final na página da loja."
            )
        }
    }
}

@Composable
private fun HeroBanner() {
    val days = remember { daysToBlackFriday() }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(
                Brush.horizontalGradient(listOf(Color(0xFFFF5A1F), Color(0xFFFF2E7E)))
            )
            .padding(20.dp)
    ) {
        Column {
            Text(
                text = "Achou, comprou, economizou! 🔥",
                color = Color.White,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.ExtraBold
            )
            Spacer(Modifier.size(6.dp))
            Text(
                text = "As promoções das principais lojas num só lugar.",
                color = Color.White.copy(alpha = 0.92f),
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.size(12.dp))
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(Color.White.copy(alpha = 0.22f))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = if (days == 0L) "🛍️ Hoje é Black Friday!" else "⏳ Faltam $days dias para a Black Friday",
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }
    }
}
