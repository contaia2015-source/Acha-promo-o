package br.com.achapromo.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import br.com.achapromo.ui.EmptyState
import br.com.achapromo.ui.MainViewModel
import br.com.achapromo.ui.OfferCard
import br.com.achapromo.ui.ScreenHeader
import br.com.achapromo.util.openUrl

@Composable
fun FavoritesScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val favorites = vm.favoriteOffers

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            ScreenHeader(
                title = "Favoritos",
                subtitle = "Suas ofertas salvas ficam aqui."
            )
        }

        if (favorites.isEmpty()) {
            item {
                EmptyState(
                    emoji = "💛",
                    title = "Nenhum favorito ainda",
                    message = "Toque no coração de uma oferta para guardá-la e comparar com calma depois."
                )
            }
        }

        items(favorites, key = { it.id }) { offer ->
            OfferCard(
                offer = offer,
                isFavorite = true,
                onToggleFavorite = { vm.toggleFavorite(offer.id) },
                onOpen = { context.openUrl(offer.store.searchUrl(offer.searchTerm)) }
            )
        }
    }
}
