package br.com.achapromo.data

enum class Category(val label: String, val emoji: String) {
    ALL("Tudo", "🔥"),
    PHONES("Celulares", "📱"),
    TECH("Informática", "💻"),
    APPLIANCES("Eletro", "🧊"),
    HOME("Casa", "🏠"),
    FASHION("Moda", "👕"),
    BEAUTY("Beleza", "💄"),
    GAMES("Games", "🎮")
}

data class Store(
    val name: String,
    val color: Long,
    val tagline: String,
    val homeUrl: String,
    val tips: List<String>,
    val searchUrl: (String) -> String
)

data class Offer(
    val id: Int,
    val title: String,
    val store: Store,
    val category: Category,
    val oldPrice: Double,
    val price: Double,
    val emoji: String,
    val coupon: String? = null,
    val freeShipping: Boolean = false,
    val tag: String? = null,
    val searchTerm: String = title
) {
    val discountPercent: Int
        get() = (((oldPrice - price) / oldPrice) * 100).toInt()
}
