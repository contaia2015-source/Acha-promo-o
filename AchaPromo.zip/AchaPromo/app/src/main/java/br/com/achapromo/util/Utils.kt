package br.com.achapromo.util

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import java.text.NumberFormat
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.time.temporal.TemporalAdjusters
import java.util.Locale

private val ptBr = Locale("pt", "BR")

fun formatBrl(value: Double): String = NumberFormat.getCurrencyInstance(ptBr).format(value)

fun formatPercent(value: Double): String = String.format(ptBr, "%.1f", value)

fun Context.openUrl(url: String) {
    try {
        startActivity(
            Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(this, "Não foi possível abrir o link", Toast.LENGTH_SHORT).show()
    }
}

/** Converte "1299,90" ou "1299.90" em Double. */
fun String.toBrNumber(): Double? = trim().replace(',', '.').toDoubleOrNull()

/** Dias até a próxima Black Friday (última sexta-feira de novembro). */
fun daysToBlackFriday(today: LocalDate = LocalDate.now()): Long {
    fun blackFriday(year: Int): LocalDate =
        LocalDate.of(year, 11, 1).with(TemporalAdjusters.lastInMonth(DayOfWeek.FRIDAY))

    var target = blackFriday(today.year)
    if (target.isBefore(today)) target = blackFriday(today.year + 1)
    return ChronoUnit.DAYS.between(today, target)
}
