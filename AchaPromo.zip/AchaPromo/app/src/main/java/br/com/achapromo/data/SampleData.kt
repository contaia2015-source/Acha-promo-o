package br.com.achapromo.data

import java.net.URLEncoder

/**
 * DADOS DE DEMONSTRAÇÃO.
 * Os preços abaixo são ilustrativos. Para um app real, troque [SampleData.offers]
 * por uma fonte de dados (API própria, Firebase, JSON remoto ou programas de afiliados).
 */
object Stores {
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    val Amazon = Store(
        name = "Amazon",
        color = 0xFF232F3E,
        tagline = "Variedade e entrega rápida em itens elegíveis",
        homeUrl = "https://www.amazon.com.br/gp/goldbox",
        tips = listOf(
            "Veja se o item é \"vendido e entregue pela Amazon\" para ter mais previsibilidade.",
            "Compare o frete e o prazo antes de fechar o carrinho.",
            "Leia as avaliações mais recentes, não só a nota geral."
        )
    ) { "https://www.amazon.com.br/s?k=${enc(it)}" }

    val MercadoLivre = Store(
        name = "Mercado Livre",
        color = 0xFFF5B800,
        tagline = "Marketplace gigante com muitos vendedores",
        homeUrl = "https://www.mercadolivre.com.br/ofertas",
        tips = listOf(
            "Confira a reputação do vendedor (cor e histórico de vendas).",
            "Prefira lojas oficiais quando o produto for de marca.",
            "Pague pela plataforma: fora dela você perde a proteção da compra."
        )
    ) { "https://lista.mercadolivre.com.br/${enc(it).replace("+", "-")}" }

    val Magalu = Store(
        name = "Magalu",
        color = 0xFF0086FF,
        tagline = "Eletros, eletrônicos e retirada em loja",
        homeUrl = "https://www.magazineluiza.com.br/selecao/ofertasdodia/",
        tips = listOf(
            "Veja se há retirada em loja para economizar no frete.",
            "Cheque o desconto no Pix e no app antes de pagar no cartão.",
            "Compare a garantia estendida: nem sempre compensa."
        )
    ) { "https://www.magazineluiza.com.br/busca/${enc(it)}/" }

    val Shopee = Store(
        name = "Shopee",
        color = 0xFFEE4D2D,
        tagline = "Cupons e ofertas relâmpago o ano todo",
        homeUrl = "https://shopee.com.br/flash_sale",
        tips = listOf(
            "Colete cupons de frete e de desconto antes de finalizar.",
            "Atenção ao prazo: alguns vendedores enviam do exterior.",
            "Olhe fotos reais enviadas por compradores nas avaliações."
        )
    ) { "https://shopee.com.br/search?keyword=${enc(it)}" }

    val Kabum = Store(
        name = "KaBuM!",
        color = 0xFFFF6500,
        tagline = "Hardware, games e tecnologia",
        homeUrl = "https://www.kabum.com.br/ofertas",
        tips = listOf(
            "Compare o preço no Pix com o parcelado: a diferença costuma ser grande.",
            "Em peças de PC, confira compatibilidade antes de comprar.",
            "Acompanhe o preço por alguns dias para saber se a oferta é boa."
        )
    ) { "https://www.kabum.com.br/busca/${enc(it)}" }

    val CasasBahia = Store(
        name = "Casas Bahia",
        color = 0xFF0A3D91,
        tagline = "Móveis, eletro e parcelamento",
        homeUrl = "https://www.casasbahia.com.br",
        tips = listOf(
            "Em móveis, confira medidas e prazo de montagem.",
            "Verifique se as parcelas são sem juros de verdade.",
            "Peça a nota fiscal e guarde-a: ela vale como garantia."
        )
    ) { "https://www.google.com/search?q=${enc("$it casas bahia")}" }

    val AliExpress = Store(
        name = "AliExpress",
        color = 0xFFE62E04,
        tagline = "Preços baixos em compras internacionais",
        homeUrl = "https://pt.aliexpress.com",
        tips = listOf(
            "Considere o prazo de entrega, que costuma ser maior.",
            "Confira o valor final com impostos no checkout.",
            "Prefira vendedores com muitas vendas e boa nota."
        )
    ) { "https://pt.aliexpress.com/wholesale?SearchText=${enc(it)}" }

    val Shein = Store(
        name = "Shein",
        color = 0xFF111111,
        tagline = "Moda e acessórios a preços acessíveis",
        homeUrl = "https://br.shein.com",
        tips = listOf(
            "Use a tabela de medidas de cada peça: tamanhos variam bastante.",
            "Veja fotos de clientes nas avaliações.",
            "Confira a política de troca e devolução antes de comprar."
        )
    ) { "https://br.shein.com/pdsearch/${enc(it)}/" }

    val all = listOf(Amazon, MercadoLivre, Magalu, Shopee, Kabum, CasasBahia, AliExpress, Shein)
}

object SampleData {
    val offers: List<Offer> = listOf(
        Offer(1, "Smart TV 50\" 4K UHD com apps de streaming", Stores.Amazon, Category.APPLIANCES, 3299.0, 2299.0, "📺", freeShipping = true, tag = "Mais vendido", searchTerm = "smart tv 50 4k"),
        Offer(2, "Smartphone 128GB tela 6,5\" câmera tripla", Stores.MercadoLivre, Category.PHONES, 1899.0, 1399.0, "📱", coupon = "DEMO10", freeShipping = true, searchTerm = "smartphone 128gb"),
        Offer(3, "Air Fryer 4L digital com timer", Stores.Magalu, Category.APPLIANCES, 499.0, 319.0, "🍟", freeShipping = true, tag = "Queridinha", searchTerm = "air fryer 4l"),
        Offer(4, "Fone Bluetooth com cancelamento de ruído", Stores.Shopee, Category.TECH, 299.0, 129.0, "🎧", coupon = "DEMOFRETE", searchTerm = "fone bluetooth cancelamento de ruido"),
        Offer(5, "SSD 1TB NVMe leitura até 3.500 MB/s", Stores.Kabum, Category.TECH, 549.0, 389.0, "💾", tag = "Pix com desconto", searchTerm = "ssd 1tb nvme"),
        Offer(6, "Sofá 3 lugares retrátil e reclinável", Stores.CasasBahia, Category.HOME, 2499.0, 1749.0, "🛋️", searchTerm = "sofa 3 lugares retratil"),
        Offer(7, "Controle sem fio para console", Stores.Amazon, Category.GAMES, 449.0, 319.0, "🎮", freeShipping = true, searchTerm = "controle sem fio console"),
        Offer(8, "Kit 5 camisetas básicas de algodão", Stores.Shein, Category.FASHION, 199.0, 99.0, "👕", coupon = "DEMO15", searchTerm = "kit camisetas basicas"),
        Offer(9, "Notebook 15,6\" 8GB RAM 256GB SSD", Stores.Magalu, Category.TECH, 2999.0, 2199.0, "💻", freeShipping = true, tag = "Volta às aulas", searchTerm = "notebook 15.6 8gb ssd"),
        Offer(10, "Relógio inteligente com monitor de saúde", Stores.AliExpress, Category.TECH, 399.0, 159.0, "⌚", searchTerm = "smartwatch monitor saude"),
        Offer(11, "Geladeira Frost Free 400L inox", Stores.CasasBahia, Category.APPLIANCES, 3999.0, 3099.0, "🧊", freeShipping = true, searchTerm = "geladeira frost free 400l"),
        Offer(12, "Kit skincare com protetor solar facial", Stores.MercadoLivre, Category.BEAUTY, 189.0, 119.0, "🧴", searchTerm = "kit skincare protetor solar"),
        Offer(13, "Teclado mecânico gamer RGB", Stores.Kabum, Category.GAMES, 399.0, 249.0, "⌨️", searchTerm = "teclado mecanico gamer"),
        Offer(14, "Aspirador de pó robô inteligente", Stores.Amazon, Category.HOME, 1599.0, 999.0, "🤖", freeShipping = true, tag = "Oferta relâmpago", searchTerm = "aspirador robo"),
        Offer(15, "Tênis esportivo leve para corrida", Stores.Shopee, Category.FASHION, 279.0, 149.0, "👟", coupon = "DEMO20", searchTerm = "tenis corrida"),
        Offer(16, "Cafeteira elétrica com jarra de 1,2L", Stores.Magalu, Category.HOME, 199.0, 129.0, "☕", searchTerm = "cafeteira eletrica"),
        Offer(17, "Smartphone 256GB 5G tela AMOLED", Stores.Amazon, Category.PHONES, 3499.0, 2699.0, "📲", freeShipping = true, searchTerm = "smartphone 256gb 5g"),
        Offer(18, "Perfume importado 100ml", Stores.MercadoLivre, Category.BEAUTY, 599.0, 389.0, "🌸", searchTerm = "perfume importado 100ml"),
        Offer(19, "Cadeira gamer ergonômica reclinável", Stores.CasasBahia, Category.GAMES, 1299.0, 799.0, "🪑", freeShipping = true, searchTerm = "cadeira gamer"),
        Offer(20, "Capa e película para celular (kit)", Stores.AliExpress, Category.PHONES, 79.0, 24.0, "🛡️", searchTerm = "capa pelicula celular"),
        Offer(21, "Máquina de lavar 12kg", Stores.Magalu, Category.APPLIANCES, 2699.0, 1899.0, "🧺", freeShipping = true, searchTerm = "maquina de lavar 12kg"),
        Offer(22, "Batom matte longa duração (kit com 3)", Stores.Shein, Category.BEAUTY, 89.0, 39.0, "💄", searchTerm = "kit batom matte")
    )
}
