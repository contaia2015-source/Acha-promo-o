package br.com.achapromo.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import br.com.achapromo.ui.Disclaimer
import br.com.achapromo.ui.ScreenHeader
import br.com.achapromo.util.formatBrl
import br.com.achapromo.util.formatPercent
import br.com.achapromo.util.toBrNumber

private val faq = listOf(
    "Como saber se a promoção é real?" to
        "Compare o preço em 2 ou 3 lojas e acompanhe o histórico do produto em sites de comparação de preços. " +
        "Desconfie de \"preço de\" muito inflado: o que importa é quanto você paga, não o tamanho do desconto. " +
        "Use a calculadora de desconto aqui na aba Guia.",
    "Posso me arrepender de uma compra online?" to
        "Sim. Pelo Código de Defesa do Consumidor (art. 49), em compras feitas fora da loja física você pode desistir " +
        "em até 7 dias corridos a partir do recebimento do produto, com devolução dos valores pagos.",
    "Como saber se a loja é confiável?" to
        "Confira CNPJ e endereço no rodapé do site, veja a reputação no Reclame Aqui e no consumidor.gov.br, " +
        "e confirme que o endereço do site é o oficial (cuidado com letras trocadas). Em marketplaces, olhe a nota do vendedor.",
    "\"Vendido por\" e \"entregue por\" são a mesma coisa?" to
        "Nem sempre. Em marketplaces, o vendedor pode ser um terceiro e a entrega ser feita por outra empresa. " +
        "Isso muda prazo, garantia e atendimento. Leia essa informação antes de pagar.",
    "Pix ou cartão: qual é melhor?" to
        "O Pix costuma ter desconto à vista. O cartão pode permitir parcelar sem juros e facilita contestar uma cobrança indevida. " +
        "Compare o valor total das duas formas com a calculadora de Pix x parcelado.",
    "O produto veio com defeito. E agora?" to
        "Guarde a nota fiscal e fale primeiro com o SAC da loja. A garantia legal é de 30 dias para produtos não duráveis " +
        "e 90 dias para duráveis, além da garantia do fabricante. Se não resolverem, use o consumidor.gov.br ou o Procon.",
    "Como usar cupons de desconto?" to
        "Normalmente há um campo \"cupom\" no carrinho. Veja as regras: valor mínimo, categorias válidas, prazo e se acumula com outras ofertas. " +
        "Em ofertas deste app com cupom, toque na etiqueta do cupom para copiar o código.",
    "Frete grátis sempre vale a pena?" to
        "Nem sempre. Compare o preço final (produto + frete) e o prazo. Às vezes um produto com frete pago sai mais barato no total.",
    "E compras internacionais?" to
        "Podem ter impostos e prazo maior. As regras de tributação mudam com o tempo, então confira o valor final com impostos " +
        "no checkout antes de pagar e prefira vendedores bem avaliados.",
    "O preço mudou na hora de pagar. O que faço?" to
        "A oferta anunciada obriga o fornecedor (CDC, art. 30 e 35). Tire prints da página e do carrinho, " +
        "fale com o SAC e, se necessário, registre reclamação no Procon ou no consumidor.gov.br.",
    "Como evitar golpes?" to
        "Desconfie de preços absurdamente baixos, links recebidos por mensagem e pedidos de pagamento fora do site oficial. " +
        "Nunca informe senhas ou códigos recebidos por SMS a ninguém."
)

private val checklist = listOf(
    "Comparei o preço em pelo menos 2 lojas",
    "Conferi quem vende e quem entrega",
    "Somei o frete e verifiquei o prazo",
    "Li avaliações recentes (inclusive as negativas)",
    "Vi a política de troca e devolução",
    "Comparei Pix x parcelado",
    "Conferi se há cupom disponível",
    "Guardei o comprovante e a nota fiscal"
)

private val calendar = listOf(
    "15 de março" to "Dia do Consumidor",
    "Maio" to "Dia das Mães (2º domingo)",
    "12 de junho" to "Dia dos Namorados",
    "Agosto" to "Dia dos Pais (2º domingo)",
    "12 de outubro" to "Dia das Crianças",
    "Última sexta de novembro" to "Black Friday",
    "Dezembro" to "Natal e liquidações de fim de ano"
)

@Composable
fun HelpScreen() {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            ScreenHeader(
                title = "Guia do consumidor",
                subtitle = "Tire dúvidas, calcule e compre com segurança."
            )
        }

        item { SectionTitle("🧮 Calculadoras") }
        item { DiscountCalculator() }
        item { InstallmentCalculator() }

        item { SectionTitle("❓ Dúvidas frequentes") }
        items(faq) { (question, answer) -> FaqItem(question, answer) }

        item { SectionTitle("✅ Checklist antes de comprar") }
        item { ChecklistCard() }

        item { SectionTitle("📅 Calendário de promoções") }
        item { CalendarCard() }

        item {
            Disclaimer(
                "Informações gerais de caráter educativo. Não substituem orientação jurídica. " +
                    "Em caso de dúvida, procure o Procon da sua cidade."
            )
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.ExtraBold,
        modifier = Modifier.padding(top = 8.dp)
    )
}

@Composable
private fun ToolCard(title: String, subtitle: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Column {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            content()
        }
    }
}

@Composable
private fun NumberField(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    decimal: Boolean = true
) {
    OutlinedTextField(
        value = value,
        onValueChange = { text -> onChange(text.filter { it.isDigit() || it == ',' || it == '.' }) },
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(
            keyboardType = if (decimal) KeyboardType.Decimal else KeyboardType.Number
        ),
        modifier = modifier
    )
}

@Composable
private fun ResultText(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodyMedium,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary
    )
}

@Composable
private fun DiscountCalculator() {
    var from by rememberSaveable { mutableStateOf("") }
    var to by rememberSaveable { mutableStateOf("") }
    val oldPrice = from.toBrNumber()
    val newPrice = to.toBrNumber()

    ToolCard("Desconto de verdade", "Descubra quanto você realmente economiza.") {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NumberField("Preço \"de\" (R$)", from, { from = it }, Modifier.weight(1f))
            NumberField("Preço \"por\" (R$)", to, { to = it }, Modifier.weight(1f))
        }
        if (oldPrice != null && newPrice != null && oldPrice > 0) {
            val pct = (oldPrice - newPrice) / oldPrice * 100
            ResultText(
                if (pct > 0) {
                    "Você economiza ${formatBrl(oldPrice - newPrice)} (${formatPercent(pct)}% de desconto)."
                } else {
                    "Sem desconto: o preço \"por\" não é menor que o \"de\"."
                }
            )
        }
    }
}

@Composable
private fun InstallmentCalculator() {
    var cash by rememberSaveable { mutableStateOf("") }
    var count by rememberSaveable { mutableStateOf("") }
    var each by rememberSaveable { mutableStateOf("") }
    val cashPrice = cash.toBrNumber()
    val parts = count.toIntOrNull()
    val partValue = each.toBrNumber()

    ToolCard("Pix x parcelado", "Veja se parcelar sai mais caro que pagar à vista.") {
        NumberField("Preço à vista / Pix (R$)", cash, { cash = it }, Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NumberField("Nº de parcelas", count, { count = it }, Modifier.weight(1f), decimal = false)
            NumberField("Valor da parcela (R$)", each, { each = it }, Modifier.weight(1f))
        }
        if (cashPrice != null && parts != null && partValue != null && parts > 0 && cashPrice > 0) {
            val total = parts * partValue
            val diff = total - cashPrice
            ResultText(
                if (diff > 0.5) {
                    "Parcelado custa ${formatBrl(total)} no total: ${formatBrl(diff)} a mais " +
                        "(+${formatPercent(diff / cashPrice * 100)}%) que à vista."
                } else {
                    "O total parcelado é praticamente igual ao à vista. Parcelar não custa a mais."
                }
            )
        }
    }
}

@Composable
private fun FaqItem(question: String, answer: String) {
    var expanded by rememberSaveable(question) { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { expanded = !expanded },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = question,
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold
                )
                Icon(
                    imageVector = if (expanded) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown,
                    contentDescription = if (expanded) "Recolher" else "Expandir"
                )
            }
            AnimatedVisibility(visible = expanded) {
                Text(
                    text = answer,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        }
    }
}

@Composable
private fun ChecklistCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(Modifier.padding(vertical = 8.dp, horizontal = 8.dp)) {
            checklist.forEach { item -> ChecklistRow(item) }
        }
    }
}

@Composable
private fun ChecklistRow(text: String) {
    var checked by rememberSaveable(text) { mutableStateOf(false) }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { checked = !checked },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(checked = checked, onCheckedChange = { checked = it })
        Text(text, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun CalendarCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            calendar.forEach { (date, event) ->
                Row(verticalAlignment = Alignment.Top) {
                    Text(
                        text = date,
                        modifier = Modifier.width(120.dp),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(Modifier.size(4.dp))
                    Text(event, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}
