package br.com.achapromo.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFFFF5A1F),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFE0D2),
    onPrimaryContainer = Color(0xFF3B1100),
    secondary = Color(0xFF3D2C8D),
    onSecondary = Color.White,
    background = Color(0xFFFFF8F4),
    onBackground = Color(0xFF231A16),
    surface = Color.White,
    onSurface = Color(0xFF231A16),
    surfaceVariant = Color(0xFFFFEDE4),
    onSurfaceVariant = Color(0xFF6B5A52)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFFF8A5C),
    onPrimary = Color(0xFF3B1100),
    primaryContainer = Color(0xFF5A2310),
    onPrimaryContainer = Color(0xFFFFDBCC),
    secondary = Color(0xFFC9BFFF),
    onSecondary = Color(0xFF241A66),
    background = Color(0xFF1A1210),
    onBackground = Color(0xFFF2DFD7),
    surface = Color(0xFF241A16),
    onSurface = Color(0xFFF2DFD7),
    surfaceVariant = Color(0xFF3A2A23),
    onSurfaceVariant = Color(0xFFD7C2B8)
)

@Composable
fun AchaPromoTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = Typography(),
        content = content
    )
}
