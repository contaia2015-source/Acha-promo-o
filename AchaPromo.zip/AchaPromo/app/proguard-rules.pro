# Regras de ProGuard/R8 adicionais (nenhuma necessária por enquanto).
